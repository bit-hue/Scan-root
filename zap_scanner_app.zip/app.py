
from flask import Flask, request, jsonify, send_file
import requests
import time
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

app = Flask(__name__)
ZAP_API = 'http://localhost:8080/JSON'

@app.route('/scan', methods=['POST'])
def scan_site():
    data = request.json
    target = data.get('url')
    if not target:
        return jsonify({'error': 'URL is required'}), 400

    scan_resp = requests.get(f'{ZAP_API}/ascan/action/scan/', params={'url': target})
    scan_id = scan_resp.json().get('scan')

    while True:
        status_resp = requests.get(f'{ZAP_API}/ascan/view/status/', params={'scanId': scan_id})
        if int(status_resp.json().get('status')) >= 100:
            break
        time.sleep(2)

    alerts_resp = requests.get(f'{ZAP_API}/core/view/alerts/', params={'baseurl': target})
    alerts = alerts_resp.json().get('alerts', [])
    return jsonify({'vulnerabilities': alerts})

@app.route('/scan/pdf', methods=['POST'])
def scan_pdf():
    data = request.json
    target = data.get('url')

    scan_resp = requests.get(f'{ZAP_API}/ascan/action/scan/', params={'url': target})
    scan_id = scan_resp.json().get('scan')

    while True:
        status_resp = requests.get(f'{ZAP_API}/ascan/view/status/', params={'scanId': scan_id})
        if int(status_resp.json().get('status')) >= 100:
            break
        time.sleep(2)

    alerts_resp = requests.get(f'{ZAP_API}/core/view/alerts/', params={'baseurl': target})
    alerts = alerts_resp.json().get('alerts', [])

    buffer = BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=A4)
    pdf.setTitle("Relatório de Vulnerabilidades")
    pdf.setFont("Helvetica-Bold", 14)
    pdf.drawString(50, 800, f"Relatório de Vulnerabilidades para {target}")
    pdf.setFont("Helvetica", 10)
    y = 780
    for alert in alerts:
        pdf.drawString(50, y, f"- {alert['alert']} ({alert['risk']})")
        y -= 15
        if y < 50:
            pdf.showPage()
            y = 800
    pdf.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name="relatorio_zap.pdf", mimetype='application/pdf')

if __name__ == '__main__':
    app.run(debug=True)
